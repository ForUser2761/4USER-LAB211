package application.ui;

public interface UIInterface<T> {
    public void input();

    public void showAll();

    public void delete();
}
