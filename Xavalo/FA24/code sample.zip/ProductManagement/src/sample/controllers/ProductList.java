package sample.controllers;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hoa Doan
 */
import java.util.ArrayList;
import sample.dto.I_List;
import sample.dto.Product;
public class ProductList extends ArrayList<Product> implements I_List {
   
    
    
}
