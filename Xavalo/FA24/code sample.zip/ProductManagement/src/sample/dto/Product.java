package sample.dto;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Hoa Doan
 */
public class Product {

     String code="", name="" ;
     int size=0 , price=0 ;
    // change properties to private.
    // create getter, setter, 
    // Create constructor have parameters( need remove init value of properties
     // override toString

    

}
